package br.com.fiap.repository.ProdutoRepository;


import java.util.ArrayList;
import java.util.HashMap;

import java.util.Map;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;

import br.com.fiap.model.ProdutoModel.ProdutoModel;

public class ProdutoRepository {
	private static Map<Long, ProdutoModel> produtos;
	
	
	public ProdutoRepository() {
		produtos = new HashMap<Long, ProdutoModel>();
		produtos.put(1L, new ProdutoModel (1L, "Produto 1", "SKU", "Descricao prod",100.00,"novo"));
		produtos.put(2L, new ProdutoModel (2L, "Produto 2", "SKU", "Descricao prod",200.00,"novo"));
		produtos.put(3L, new ProdutoModel (3L, "Produto 3", "SKU", "Descricao prod",300.00,"novo"));
		}
	
	public ArrayList<ProdutoModel> findAll(){
		
		return new ArrayList<>(produtos.values());
	}
	
	
	public ProdutoModel findById(Long id) {
		return produtos.get(id);
	}
	
		
	public void save(ProdutoModel produto) {
		Long newID = (long) (produtos.size() +1);
		produto.setId(newID);
		produtos.put(newID, produto);
	}
	
	public void update(ProdutoModel produtoModel) {
		
		produtos.put(produtoModel.getId(), produtoModel);
		
	}
	
	public void deleteById(long id) {
		
		produtos.remove(id);
		
		
	}
	
	
	}
	
	
	
	


