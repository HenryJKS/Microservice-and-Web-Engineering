package br.com.fiap.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Servlet implementation class HelloWorld
 */
@Controller
public class HelloWorld {
	
	@RequestMapping(value = {"hello", "/"}, method = RequestMethod.GET)
	public String helloWorld(Model model) {
		
		ArrayList<String> lista = new ArrayList<String>();
		lista.add("Retorno1");
		lista.add("Retorno2");
		lista.add("Retorno3");
		lista.add("");
	
		model.addAttribute("hello", lista);
		return "hello";
	}
}

