package br.com.fiap.mspagamentos.model;

public enum Status {
    CRIADO,
    CONFIRMADO,
    CANCELADO
}
