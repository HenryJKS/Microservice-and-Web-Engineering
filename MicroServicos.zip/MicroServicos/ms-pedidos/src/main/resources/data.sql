INSERT INTO tb_pedido(data_hora, status) VALUES('2023-07-19', 'CONFIRMADO');
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(1, 'Smart TV Samsung', 1);

INSERT INTO tb_pedido(data_hora, status) VALUES('2023-09-18', 'CONFIRMADO');
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(2, 'Fone de ouvido', 2);
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(1, 'Teclado', 2);
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(1, 'Mouse', 2);


