package br.com.fiap.mspedidos.model;

public enum Status {
    CANCELADO,
    PAGO,
    ENTREGUE,
    CONFIRMADO,
    PRONTO,
    REALIZADO
}
