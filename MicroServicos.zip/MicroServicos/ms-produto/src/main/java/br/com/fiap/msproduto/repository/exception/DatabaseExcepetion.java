package br.com.fiap.msproduto.repository.exception;

public class DatabaseExcepetion extends RuntimeException{

        public DatabaseExcepetion(String message) {
            super(message);
        }
}
