package br.com.fiap.msproduto.service;

import br.com.fiap.msproduto.dto.ProdutoDTO;
import br.com.fiap.msproduto.model.Produto;
import br.com.fiap.msproduto.repository.ProdutoRepository;
import br.com.fiap.msproduto.repository.exception.DatabaseExcepetion;
import br.com.fiap.msproduto.repository.exception.ResourceNotFoundException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    @Transactional(readOnly = true)
    public List<ProdutoDTO> findAll() {
        List<Produto> list = produtoRepository.findAll();
        //converter Produto para ProdutoDTO
        //usando expressão lambda
        return list.stream().map(x -> new ProdutoDTO(x)).collect(Collectors.toList());
        //return list.stream().map(ProdutoDTO::new).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProdutoDTO findById(Long id) {
        // lança exception customizada
        Produto produto = produtoRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Recurso não encontrado! Id: " + id));
        //converter produto para dto
        ProdutoDTO dto = new ProdutoDTO(produto);
        return dto;
    }

    //insert
    @Transactional
    public ProdutoDTO insert(ProdutoDTO dto) {
        Produto produto = new Produto();
        //método auxiliar para converter DTO para entity
        copyDtoToEntity(dto, produto);
        produto = produtoRepository.save(produto);
        return new ProdutoDTO(produto);
    }

    //update
    @Transactional
    public ProdutoDTO update(Long id, ProdutoDTO dto) {
        try {
            Produto produto = produtoRepository.getReferenceById(id);
            copyDtoToEntity(dto, produto);
            produto = produtoRepository.save(produto);
            return new ProdutoDTO(produto);

        } catch (EntityNotFoundException e) {
            throw new ResourceNotFoundException("Id não encontrado " + id);
        }
    }

    //delete
    @Transactional
    public void delete(Long id) {
        if (!produtoRepository.existsById(id)) {
            throw new ResourceNotFoundException("Id não encontrado " + id);
        }
        try {
            produtoRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new DatabaseExcepetion("Violação de integridade");
        }
    }


private void copyDtoToEntity(ProdutoDTO dto, Produto produto) {
        produto.setNome(dto.getNome());
        produto.setDescricao(dto.getDescricao());
        produto.setPreco(dto.getPreco());
        produto.setCaracteristica(dto.getCaracteristica());
}


}
