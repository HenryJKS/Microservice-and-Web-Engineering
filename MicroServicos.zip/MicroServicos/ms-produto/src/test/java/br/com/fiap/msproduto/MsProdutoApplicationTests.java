package br.com.fiap.msproduto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
