package br.com.fiap.mseurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
